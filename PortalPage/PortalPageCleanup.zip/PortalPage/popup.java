//document.addEventListener('DOMContentLoaded', () => {
//onst openLink = document.getElementById('openFormLink');
//const closeBtn = document.getElementById('close');
//const popup = document.getElementById('formPopup');

// Open popup when link is clicked
//openLink.addEventListener('click', (event) => {
  //event.preventDefault(); 
  //popup.showModal();      
//});

// Close popup when cancel button is clicked
//closeBtn.addEventListener('click', () => {
  //popup.close();
//})});


